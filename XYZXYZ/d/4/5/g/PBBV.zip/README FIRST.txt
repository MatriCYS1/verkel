how to use:    (writed by HereH)



first dont join  arras.io.  use adblocker, go open arras.io select server  and then
run the PBBV.exe without clicking play. then bot will be sucesfully activated.
if you cant join the server in 6 seconds, go press "End" to stop the bot.









You can end the bot with this key:  " End ".